# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dl_scratch3',
 'dl_scratch3.functions',
 'dl_scratch3.steps',
 'dl_scratch3.steps.step07',
 'dl_scratch3.steps.step08',
 'dl_scratch3.steps.step09',
 'dl_scratch3.steps.step11',
 'dl_scratch3.steps.step12',
 'dl_scratch3.steps.step13',
 'dl_scratch3.steps.step14',
 'dl_scratch3.steps.step16',
 'dl_scratch3.steps.step17',
 'dl_scratch3.steps.step18',
 'dl_scratch3.steps.step19',
 'dl_scratch3.steps.step20',
 'dl_scratch3.steps.step21',
 'dl_scratch3.steps.step22']

package_data = \
{'': ['*']}

install_requires = \
['classopt>=0.1.9,<0.2.0',
 'coloredlogs>=15.0.1,<16.0.0',
 'jupyterlab>=3.4.2,<4.0.0',
 'matplotlib>=3.5.2,<4.0.0',
 'nptyping>=2.1.1,<3.0.0',
 'numpy>=1.22.4,<2.0.0',
 'opencv-python>=4.5.5,<5.0.0',
 'pandas>=1.4.2,<2.0.0',
 'plotly>=5.8.0,<6.0.0',
 'pretty-errors>=1.2.25,<2.0.0',
 'pydantic>=1.10.1,<2.0.0',
 'pytest>=7.1.2,<8.0.0',
 'rich>=12.4.4,<13.0.0',
 'scikit-learn>=1.1.1,<2.0.0',
 'scipy>=1.8.1,<2.0.0',
 'seaborn>=0.11.2,<0.12.0',
 'tensorflow-macos>=2.9.2,<3.0.0',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'dl-scratch3',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Joichiro433',
    'author_email': 'joichiro322@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
